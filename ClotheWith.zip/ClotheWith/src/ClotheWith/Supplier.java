package ClotheWith;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Supplier {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton SupplierButton,deleteButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lblS_Name,lblS_id,lblShipment_id;
	private JTextField txtS_Name,txtS_id,txtShipment_id;
	private List SupplierIDList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public Supplier(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		lblS_Name=new JLabel("S_Name");
		lblS_id=new JLabel("S_id");
		lblShipment_id=new JLabel("Shipment_id");
		txtS_Name=new JTextField(20);
		txtS_id=new JTextField(5);
		txtShipment_id=new JTextField(5);
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","Tanmayee","vasavi");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loadSupplier() {
		try {
			SupplierIDList.removeAll();
			rs=statement.executeQuery("select S_id from Supplier");
			while(rs.next()) {
				SupplierIDList.add(rs.getString("S_id"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}

	public void buildGUI() {
		SupplierButton=new JButton("Insert/Submit");
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				 txtS_Name.setText(null);
				 txtS_id.setText(null);
				 txtShipment_id.setText(null); 
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				   
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(3,2));
				 p1.add(lblS_Name);
				 p1.add( txtS_Name);
				 p1.add(lblS_id);
				 p1.add( txtS_id);
				 p1.add(lblShipment_id);
				 p1.add(txtShipment_id);
				 p3=new JPanel(new FlowLayout());
				 p3.add(SupplierButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.orange);
				p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.pink) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					// p2.add(txtf1);
					 SupplierIDList=new List(10);
					 loadSupplier();
					 p2.add(SupplierIDList);p2.setBackground(Color.gray) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
			
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 SupplierButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO Supplier VALUES("+txtS_id.getText()+",'"+txtS_Name.getText()+"',"+txtShipment_id.getText()+")";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully"); 
					loadSupplier();
					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("Delete");
				
				txtS_Name.setText(null);
				txtS_id.setText(null);
				txtShipment_id.setText(null); 
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			/*
*****************************************************************
*/
				 p1.setLayout(new GridLayout(3,2));
				 p1.add(lblS_Name);
				 p1.add(txtS_Name);
				 p1.add(lblS_id);
				 p1.add(txtS_id);
				 p1.add(lblShipment_id);
				 p1.add(txtShipment_id);
				// p1.add(deleteButton);
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.orange);
				p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.pink) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					// p2.add(txtf1);
					 SupplierIDList=new List(10);
					 loadSupplier();
					 p2.add(SupplierIDList);p2.setBackground(Color.gray) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 SupplierIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from Supplier");
								while (rs.next()) 
								{
									if (rs.getString("S_id").equals(SupplierIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtS_Name.setText(rs.getString("S_Name"));
									txtS_id.setText(rs.getString("S_id"));
									txtShipment_id.setText(rs.getString("Shipment_id")); 
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});	
				
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					String Shipment=JOptionPane.showInputDialog(p,"Enter the Shipment id");
					
					txtShipment_id.setText(Shipment);
					int a=JOptionPane.showConfirmDialog(p,"Are you sure you want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM Supplier WHERE S_id="+txtS_id.getText()+"AND Shipment_id='"+txtShipment_id.getText()+"'";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");
					loadSupplier();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("Update/Modify");
				txtS_Name.setText(null);
				txtS_id.setText(null);
				txtShipment_id.setText(null); 
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(3,2));
				 p1.add(lblS_Name);
				 p1.add(txtS_Name);
				 p1.add(lblS_id);
				 p1.add(txtS_id);
				 p1.add(lblShipment_id);
				 p1.add(txtShipment_id);
				 
				 
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.orange);
				p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.pink) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					// p2.add(txtf1);
					 SupplierIDList=new List(10);
					 loadSupplier();
					 p2.add(SupplierIDList);p2.setBackground(Color.gray) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 SupplierIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from Supplier");
								while (rs.next()) 
								{
									if (rs.getString("S_id").equals(SupplierIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtS_Name.setText(rs.getString("S_Name"));
									txtS_id.setText(rs.getString("S_id"));
									txtShipment_id.setText(rs.getString("Shipment_id")); 
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});	
				
				
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					loadSupplier();
					String Shipment=JOptionPane.showInputDialog(p,"Enter the new Shipment id");
					
					
					txtShipment_id.setText(Shipment);
					
					 String query=" update Supplier set Shipment_id="+Shipment+" where S_id="+txtS_id.getText();
					
					 int i=statement.executeUpdate(query);
					
					JOptionPane.showMessageDialog(p,"\nUpdated "+i+" rows succesfully");
					loadSupplier();
					
					
				}
				catch(SQLException updateException){
					
					displaySQLErrors(updateException);
				}
				
				 }
			
			
				 	});
			}
			});
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("Supplier view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);p1.setBackground(Color.cyan) ;p2.setBackground(Color.cyan) ;
				p.add(p1);p.add(p2);
				 p.setLayout(new FlowLayout());
				
					
				p.setBounds(500,800,300,300);
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						    
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("Supplier details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("D_Name");
						       model.addColumn("D_id");
						       model.addColumn("D_id");
						      
						       try {
									
									rs=statement.executeQuery("select * from Supplier");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("S_Name"), rs.getString("S_id"),rs.getString("Shipment_id")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 150, 150); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(400, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
	
	
	
}
