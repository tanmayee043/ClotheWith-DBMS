package ClotheWith;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Employee{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,updateButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lblE_Name,lblE_id,lblE_Phone;
	private JTextField txtE_Name,txtE_id,txtE_Phone;
	
	private List EmployeeIDList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public Employee(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		
		lblE_id=new JLabel("Employee ID");
		lblE_Name=new JLabel("Employee Name");
		lblE_Phone=new JLabel("Phone");
		
		
		
		txtE_id=new JTextField(5);
		txtE_Name=new JTextField(20);
		txtE_Phone=new JTextField(10);
		
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","Tanmayee","vasavi");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loadEmployee() {
		try {
			EmployeeIDList.removeAll();
			rs=statement.executeQuery("select E_id from Employees");
			while(rs.next()) {
				EmployeeIDList.add(rs.getString("E_id"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}

	public void buildGUI() {
		
		
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				insertButton=new JButton("Insert/Submit");
				txtE_id.setText(null);
				txtE_Name.setText(null);
				txtE_Phone.setText(null);
				
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,2));
				 p1.add(lblE_id);
				 p1.add(txtE_id);
				 p1.add(lblE_Name);
				 p1.add(txtE_Name);
				 p1.add(lblE_Phone);
				 p1.add(txtE_Phone);
				
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.orange);
				 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				 
				
					 
				 
				
				 p2 = new JPanel(new FlowLayout());
					
					 EmployeeIDList=new List(10);
					 loadEmployee();
					 p2.add(EmployeeIDList);p2.setBackground(Color.cyan) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);p.add(p3);
				 p. add(p2);
				 
				
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
					
				 insertButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO Employees VALUES("+txtE_id.getText()+",'"+txtE_Name.getText()+"',"+txtE_Phone.getText()+")";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");loadEmployee();
					
					
					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("Delete");
				
				txtE_id.setText(null);
				txtE_Name.setText(null);
				txtE_Phone.setText(null);
				
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,2));
				 p1.add(lblE_id);
				 p1.add(txtE_id);
				 p1.add(lblE_Name);
				 p1.add(txtE_Name);
				 p1.add(lblE_Phone);
				 p1.add(txtE_Phone);
				 
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.orange);
				 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				 
				
					 
				// p1.setBounds(100,100,500,300);
				
				 p2 = new JPanel(new FlowLayout());
					
					 EmployeeIDList=new List(10);
					 loadEmployee();
					 p2.add(EmployeeIDList);p2.setBackground(Color.cyan) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);p.add(p3);
				 p. add(p2);
				  EmployeeIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from Employees");
								while (rs.next()) 
								{
									if (rs.getString("E_id").equals(EmployeeIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtE_id.setText(rs.getString("E_id"));
									txtE_Name.setText(rs.getString("E_Name"));
									txtE_Phone.setText(rs.getString("E_Phone"));
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});				
				 
				 p.setLayout(new BorderLayout());
				
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure you want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM Employees WHERE E_id="+EmployeeIDList.getSelectedItem();
				
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loadEmployee();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("Update/Modify");
				txtE_id.setText(null);
				txtE_Name.setText(null);
				txtE_Phone.setText(null);
				
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,2));
				 p1.add(lblE_id);
				 p1.add(txtE_id);
				 p1.add(lblE_Name);
				 p1.add(txtE_Name);
				 p1.add(lblE_Phone);
				 p1.add(txtE_Phone);
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.orange);
				 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				
				 p2 = new JPanel(new FlowLayout());
					
					 EmployeeIDList=new List(10);
					 loadEmployee();
					 p2.add(EmployeeIDList);p2.setBackground(Color.cyan) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);p.add(p3);
				 p. add(p2);
				  EmployeeIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from Employees");
								while (rs.next()) 
								{
									if (rs.getString("E_id").equals(EmployeeIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtE_id.setText(rs.getString("E_id"));
									txtE_Name.setText(rs.getString("E_Name"));
									txtE_Phone.setText(rs.getString("E_Phone"));
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 
				 p.setLayout(new BorderLayout());
				
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
					
				
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {
								
								int a=JOptionPane.showConfirmDialog(p,"Are you sure you want to update:");
								if(a==JOptionPane.YES_OPTION){  
								String query="update Designer set E_Name='"+txtE_Name.getText()+"',E_Phone="+txtE_Phone.getText()+" WHERE E_id= "+EmployeeIDList.getSelectedItem();
								
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loadEmployee();
								}
								
								
							}
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				
				 }
			
			
				 	});
			}
			});
		
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("Employee view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);p1.setBackground(Color.cyan) ;p2.setBackground(Color.cyan) ;
				p.add(p1);p.add(p2); p.setLayout(new FlowLayout());
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						      
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("Employee details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("Employee id");
						       model.addColumn("Employee Name");
						       model.addColumn("PhoneNo");
						       
						      
						      
						       try {
									
									rs=statement.executeQuery("select * from Employees");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("E_id"), rs.getString("E_Name"),rs.getString("E_Phone")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 300, 300); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(800, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
	
	
	


	
	
	
}

