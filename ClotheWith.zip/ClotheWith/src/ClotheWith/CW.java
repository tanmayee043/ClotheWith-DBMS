package ClotheWith; 
import java.awt.Color; 
import java.awt.FlowLayout; 
import java.awt.Font; 
import java.awt.GridLayout; 
import java.awt.Label; 
import java.awt.event.WindowAdapter; 
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.JFrame; 
import javax.swing.JLabel; 
import javax.swing.JMenu; 
import javax.swing.JMenuBar; 
import javax.swing.JMenuItem; 
import javax.swing.JOptionPane; 
import javax.swing.JPanel; 
import java.awt.Dimension; 
import javax.swing.border.Border;
public class CW extends JFrame{ 
 	/** 
 	 *   	             */ 
 	private static final long serialVersionUID = 1L; 
 
	 private JMenuBar cw;

	private JMenu cwdesigner;  
	private JMenu cwsupplier;  	    
	private JMenu cwitems;  	
	private JMenu cwstore;  	
	private JMenu cwmanager;  	
	private JMenu cwemployees;  	
	private JMenu cwcustomers;  	
 	 
	private JMenuItem insert1,update1,delete1,view1;  	
	private JMenuItem insert2,update2,delete2,view2;  	
	private JMenuItem insert3,update3,delete3,view3;  	
	private JMenuItem insert4,update4,delete4,view4;  	
	private JMenuItem insert5,update5,delete5,view5;  	
	private JMenuItem insert6,update6,delete6,view6;  	
	private JMenuItem insert7,update7,delete7,view7; 
 	 

                private JLabel labelName; 
 
 	private static JPanel p0,p1; 	
	void initialize() { 
 	 	cw=new JMenuBar(); 
 	 	cwdesigner= new JMenu("Designer");
		cwsupplier= new JMenu("Supplier");  	 
        cwitems= new JMenu("Items");  	 	
        cwstore= new JMenu("Store");  	 	
        cwmanager= new JMenu("Manager");  	 	                          
		cwemployees= new JMenu("Employees");  	 	                          
		cwcustomers= new JMenu("Customers"); 
	labelName=new JLabel("ClotheWith", JLabel.CENTER);  
	labelName.setPreferredSize(new Dimension(1000,100));
	labelName.setFont(new Font("Serif",Font.BOLD+Font.ITALIC,24));
	Border border= BorderFactory.createLineBorder(Color.BLACK);
	labelName.setBorder(border);
	p1=new JPanel(); 
	p0=new JPanel(); 
		insert1=new JMenuItem("Insert"); 
		update1=new JMenuItem("Update"); 
		delete1=new JMenuItem("Delete"); 
		view1=new JMenuItem("View"); 
		insert2=new JMenuItem("Insert"); 
		update2=new JMenuItem("Update"); 
		delete2=new JMenuItem("Delete"); 
 	 	view2=new JMenuItem("View");  	 	                          
		insert3=new JMenuItem("Insert");  	 
        update3=new JMenuItem("Update");  	 
        delete3=new JMenuItem("Delete");  	 
        view3=new JMenuItem("View");  	 
		insert4=new JMenuItem("Insert");  	 
		update4=new JMenuItem("Update");  	 
		delete4=new JMenuItem("Delete");  	 
		view4=new JMenuItem("View");  	 
		insert5=new JMenuItem("Insert");  	 
		update5=new JMenuItem("Update");  	 
		delete5=new JMenuItem("Delete");  	 
		view5=new JMenuItem("View");  	 
		insert6=new JMenuItem("Insert");  	 
		update6=new JMenuItem("Update");  	 
		delete6=new JMenuItem("Delete");  	 
		view6=new JMenuItem("View");  	 
		insert7=new JMenuItem("Insert");  	 
		update7=new JMenuItem("Update");  	 
		delete7=new JMenuItem("Delete");  	 
		view7=new JMenuItem("View");  	 
		insert1=new JMenuItem("Insert"); 
 	 	update1=new JMenuItem("Update"); 
		delete1=new JMenuItem("Delete"); 
 	 	view1=new JMenuItem("View"); 
 	}

void addComponentsToFrame() {  	 	 
			cwdesigner.add(insert1);  	 	 
			cwdesigner.add(delete1);  	 	 
			cwdesigner.add(update1);  	 	 
			cwdesigner.add(view1);  	 	  
			cwsupplier.add(insert2);  	 	 
			cwsupplier.add(delete2);  	 	 
			cwsupplier.add(update2);  	 	 
			cwsupplier.add(view2);  	 	
			cwitems.add(insert3);  	 	 
			cwitems.add(delete3);  	 	 
			cwitems.add(update3);  	 	 
			cwitems.add(view3);  	 	  
			cwstore.add(insert4);  	 	 
			cwstore.add(delete4);  	 	 
			cwstore.add(update4);  	 	 
			cwstore.add(view4);  	 	  
			cwmanager.add(insert5);  	 	 
			cwmanager.add(delete5);  	 	 
			cwmanager.add(update5);  	 	 
			cwmanager.add(view5);  	 	  
			cwemployees.add(insert6);  	 	 
			cwemployees.add(delete6);  	 	 
			cwemployees.add(update6);  	 	 
			cwemployees.add(view6);  	 	  
			cwcustomers.add(insert7);  	 	
			cwcustomers.add(delete7);  	 	 
			cwcustomers.add(update7);  	 	 
			cwcustomers.add(view7);  	 	 
			cw.add(cwdesigner);  	 	 
			cw.add(cwsupplier);  	 	
			cw.add(cwitems);  	 	 
			cw.add(cwstore);  	 	 
			cw.add(cwmanager);  	 	 
			cw.add(cwemployees);  	 	 
			cw.add(cwcustomers);  	 	 
			setJMenuBar(cw);  
 	 	 p1.add(labelName);
		 p1.setAlignmentY(CENTER_ALIGNMENT);  
 	 	 p1.setBounds(500,500,8000,1000); 	  	 	                           
		 p0.add(p1); 
 	 	 p0.setBackground(Color.ORANGE); 
 	 	 add(p0); 
 	} 
/*********************************************************************************************************/
void closeWindow(){ 
 	 	try { 
 	 	 	int a=JOptionPane.showConfirmDialog(this,"Are you sure want to Quit ClotheWith:"); 
 	 	 	if(a==JOptionPane.YES_OPTION){    	 	 	 	
				JOptionPane.showMessageDialog(this, 
 	 	 	 	 	   "Thank you!\nExiting ClotheWith","Quit", 
 	 	 	 	 	    JOptionPane.WARNING_MESSAGE); 
 	 	 	 	System.exit(0); 
 	 	 	} 
 	 	 	else if (a== JOptionPane.NO_OPTION) { 
 	 	 	 	setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE); 
 	 	 	} 
 	 	 	else if (a== JOptionPane.CANCEL_OPTION) { 
 	 	 	 	setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE); 
 	 	 	} 
 	 	} 
 	 	 	catch(Exception e) {  	 	 	 	
				System.out.println(e); 
 	 	 	 	} 
 	} 
 	void register() { 
			Designer deg=new Designer(p0,CW.this,insert1,delete1,update1,view1); 
			deg.buildGUI(); 
			Item ite=new Item(p0,CW.this,insert3,delete3,update3,view3);  
			ite.buildGUI(); 
			Supplier sup=new Supplier(p0,CW.this,insert2,delete2,update2,view2);  
			sup.buildGUI(); 
			Store sto=new Store(p0,CW.this,insert4,delete4,update4,view4);  
			sto.buildGUI(); 
			Manager man=new Manager(p0,CW.this,insert5,delete5,update5,view5);  
			man.buildGUI(); 
			Employee emp=new Employee(p0,CW.this,insert6,delete6,update6,view6);   	 	
			emp.buildGUI();  	 	
			Customers cus=new Customers(p0,CW.this,insert7,delete7,update7,view7);   	 	
			cus.buildGUI(); 
 	 	addWindowListener(new WindowAdapter(){ 
 	 	 	public void windowClosing(WindowEvent we)  
 	 	 	{  
 	 	 	 	closeWindow(); 
 	 	 	}  
 	 	});  
 	 	 
} 
public CW() { 
 	 	initialize();  	 	
		addComponentsToFrame();  	 	
		register(); 
 	 	pack(); 
 	// 	setBackground(Color.PINK);  	 	
		setTitle("Clothe With- Store"); 
 	 	setSize(800,800);  	 	
		setVisible(true); 
 	} 
} 
